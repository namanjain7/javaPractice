There are files which are separate classes and each class has some general algorithms.
The code is not a part of a project, this is just a reference code which includes some general algorithms.
Right now the main file is empty, you can test the classses according to your own test cases.
I made the code short so that you can go through the entire code quickly.
I have many cool projects. I would really love to show you.