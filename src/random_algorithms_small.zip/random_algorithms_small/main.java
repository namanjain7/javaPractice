import java.math.BigDecimal;
import java.sql.Array;
import java.util.*;

public class main {

    //private static final int y = 10;      //Global variable declaration

    public static void main(String args[]){
        //See other files for methods and classes implementation
        return;
    }
}


